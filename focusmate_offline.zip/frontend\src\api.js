﻿export async function getStats(){ const res = await fetch('/api/stats', {credentials:'include'}); if(!res.ok) throw new Error('No stats'); return await res.json(); }
