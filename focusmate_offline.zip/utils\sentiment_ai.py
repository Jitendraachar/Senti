﻿def analyze_sentiment(text: str):
    text = (text or '').lower()
    positives = ['good','happy','calm','focused','relaxed','motivated','great','productive']
    negatives = ['sad','anxious','stressed','overwhelmed','panic','depressed','tired','distracted']
    score = 0
    for p in positives:
        if p in text: score += 1
    for n in negatives:
        if n in text: score -= 1
    if score > 0: return 'positive', min(score/5.0, 1.0)
    if score < 0: return 'negative', min(abs(score)/5.0, 1.0)
    return 'neutral', 0.0
